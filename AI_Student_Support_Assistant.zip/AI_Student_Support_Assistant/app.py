import ollama


def ask_student(question):
    prompt = f"""
You are an AI Student Support Assistant for college students.

Your job is to help students with:
- Academic questions
- Study planning
- Project guidance
- Programming doubts
- Exam preparation
- College-related general guidance
- Career guidance

Give simple, clear and useful answers.
If you are not sure about something, clearly say that you are not sure.

Student's question:
{question}
"""

    response = ollama.chat(
        model="llama3.2",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response["message"]["content"]


def main():
    print("=" * 60)
    print("       AI STUDENT SUPPORT ASSISTANT")
    print("=" * 60)
    print("Type 'exit' to close the assistant.\n")

    while True:
        question = input("Student: ")

        if question.lower() == "exit":
            print("\nThank you! Goodbye.")
            break

        if not question.strip():
            print("Please enter a question.\n")
            continue

        print("\nAI Assistant:", end=" ")

        try:
            answer = ask_student(question)
            print(answer)
        except Exception as error:
            print(f"\nError: {error}")

        print()


if __name__ == "__main__":
    main()