# AI Student Support Assistant

## Project Overview

AI Student Support Assistant is a simple AI-based chatbot that helps college students by answering their academic and general student-related questions.

The application uses Python and Ollama with the Llama 3.2 local AI model to generate responses. The AI model runs locally through Ollama.

## Objectives

- Provide quick answers to student questions.
- Help students with academic topics.
- Provide study guidance and exam preparation support.
- Give programming and project-related guidance.
- Demonstrate the use of a local Large Language Model (LLM).

## Features

- Student question and answer system
- AI-powered responses
- Local AI model using Ollama
- Simple command-line interface
- No cloud API key required
- Runs inside a Python virtual environment

## Technologies Used

- Python 3.12
- Ollama
- Llama 3.2
- Ollama Python Library
- Visual Studio Code
- Python Virtual Environment
- Git and GitHub

## System Architecture

Student
    ↓
Python Application
    ↓
Ollama
    ↓
Llama 3.2
    ↓
AI Response
    ↓
Student

## Project Structure

```text
AI_Student_Support_Assistant/
│
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── venv/